export declare function initSecond(): void;
