export declare function initHour(): void;
