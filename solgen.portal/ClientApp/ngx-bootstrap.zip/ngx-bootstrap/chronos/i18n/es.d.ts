import { LocaleData } from '../locale/locale.class';
export declare const esLocale: LocaleData;
