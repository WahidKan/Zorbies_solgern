export declare function mod(n: number, x: number): number;
export declare function absFloor(num: number): number;
