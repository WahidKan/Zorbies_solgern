export declare function zeroFill(num: number, targetLength: number, forceSign?: boolean): string;
