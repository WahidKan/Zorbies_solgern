export declare function compareArrays<T>(array1: T[], array2: T[], dontConvert: boolean): number;
