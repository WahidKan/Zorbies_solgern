/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @record
 */
export function ListenOptions() { }
if (false) {
    /** @type {?|undefined} */
    ListenOptions.prototype.target;
    /** @type {?|undefined} */
    ListenOptions.prototype.targets;
    /** @type {?|undefined} */
    ListenOptions.prototype.triggers;
    /** @type {?|undefined} */
    ListenOptions.prototype.outsideClick;
    /** @type {?|undefined} */
    ListenOptions.prototype.outsideEsc;
    /** @type {?|undefined} */
    ListenOptions.prototype.show;
    /** @type {?|undefined} */
    ListenOptions.prototype.hide;
    /** @type {?|undefined} */
    ListenOptions.prototype.toggle;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGlzdGVuLW9wdGlvbnMubW9kZWwuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9uZ3gtYm9vdHN0cmFwL2NvbXBvbmVudC1sb2FkZXIvIiwic291cmNlcyI6WyJsaXN0ZW4tb3B0aW9ucy5tb2RlbC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBR0EsbUNBU0M7OztJQVJDLCtCQUFxQjs7SUFDckIsZ0NBQXdCOztJQUN4QixpQ0FBa0I7O0lBQ2xCLHFDQUF1Qjs7SUFDdkIsbUNBQXFCOztJQUNyQiw2QkFBdUI7O0lBQ3ZCLDZCQUF1Qjs7SUFDdkIsK0JBQXlCIiwic291cmNlc0NvbnRlbnQiOlsiLyogdHNsaW50OmRpc2FibGUtbmV4dC1saW5lOiBuby1hbnkgKi9cbmV4cG9ydCB0eXBlIEJzRXZlbnRDYWxsYmFjayA9IChldmVudD86IGFueSkgPT4gYm9vbGVhbiB8IHZvaWQ7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTGlzdGVuT3B0aW9ucyB7XG4gIHRhcmdldD86IEhUTUxFbGVtZW50O1xuICB0YXJnZXRzPzogSFRNTEVsZW1lbnRbXTtcbiAgdHJpZ2dlcnM/OiBzdHJpbmc7XG4gIG91dHNpZGVDbGljaz86IGJvb2xlYW47XG4gIG91dHNpZGVFc2M/OiBib29sZWFuO1xuICBzaG93PzogQnNFdmVudENhbGxiYWNrO1xuICBoaWRlPzogQnNFdmVudENhbGxiYWNrO1xuICB0b2dnbGU/OiBCc0V2ZW50Q2FsbGJhY2s7XG59XG4iXX0=