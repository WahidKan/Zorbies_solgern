import { BsDatepickerConfig } from './bs-datepicker.config';
export declare class BsDaterangepickerConfig extends BsDatepickerConfig {
    displayMonths: number;
}
