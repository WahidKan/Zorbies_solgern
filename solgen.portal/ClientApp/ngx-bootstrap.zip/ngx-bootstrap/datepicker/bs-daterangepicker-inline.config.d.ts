import { BsDatepickerConfig } from './bs-datepicker.config';
export declare class BsDaterangepickerInlineConfig extends BsDatepickerConfig {
    displayMonths: number;
    /** turn on/off animation */
    isAnimated: boolean;
}
