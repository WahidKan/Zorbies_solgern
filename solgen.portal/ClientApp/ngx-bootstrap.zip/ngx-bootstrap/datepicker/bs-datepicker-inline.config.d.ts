import { BsDatepickerConfig } from './bs-datepicker.config';
export declare class BsDatepickerInlineConfig extends BsDatepickerConfig {
}
