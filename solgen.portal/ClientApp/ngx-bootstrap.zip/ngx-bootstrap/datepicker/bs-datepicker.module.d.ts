import { ModuleWithProviders } from '@angular/core';
export declare class BsDatepickerModule {
    static forRoot(): ModuleWithProviders;
}
